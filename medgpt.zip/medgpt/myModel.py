#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt

import sys
import json
import numpy as np

inputData = json.loads(sys.argv[1])
input_array = np.array(inputData)

# In[2]:

pd.set_option("display.max_rows", None)
pd.set_option("display.max_columns", None)


# In[6]:

import os
# for dirname, _, filenames in os.walk('data'):
#     for filename in filenames:
#         print(os.path.join(dirname, filename))


# In[7]:

train = pd.read_csv('data/Training.csv') 
test = pd.read_csv('data/Testing.csv') 


train = train.drop(["Unnamed: 133"],axis=1)


# In[13]:


A = train[["prognosis"]] 
B = train.drop(["prognosis"],axis=1)

C = test.drop(["prognosis"],axis=1) 
x_train, x_test, y_train, y_test = train_test_split(B,A,test_size=0.2)


# In[14]:


mod = RandomForestClassifier(n_estimators = 100,n_jobs = 5, criterion= 'entropy',random_state = 42)


# In[ ]:


mod = mod.fit(x_train,y_train.values.ravel())
pred = mod.predict(x_test)


# In[15]:


metrics.accuracy_score(y_test, pred)


# In[16]:


report = classification_report(y_test, pred, output_dict=True)
pd.DataFrame(report).transpose()
cm = confusion_matrix(y_test, pred)
pd.DataFrame(cm)


# In[20]:


# input_data = (0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)


# change the input data to a numpy array

input_data_as_numpy_array= input_array
# reshape the numpy array as we are predicting for only on instance
input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

prediction = mod.predict(input_data_reshaped)
output_data = prediction.tolist()


json.dump(output_data, sys.stdout)

# if (prediction[0]== 0):
#   print('The Person does not have any infection')
# else:
#   print('The Person has '+str(prediction))






