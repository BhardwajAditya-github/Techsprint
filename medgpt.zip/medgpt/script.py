import sys
import json
import numpy as np

inputData = np.array(json.loads(sys.argv[1]))