const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const { PythonShell } = require('python-shell');
// const joblib = require('joblib');
const fs = require('fs');
const msgpack = require('msgpack5')();
const axios = require("axios");

const { spawn } = require('child_process');




const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json())
app.use("/route",express.static("public"));

const symptomArray = new Array(132);
var disease = "";
app.get("/",function(request,response){
    response.render("home",{disease:disease});
    disease = "";
})

var bmiValue = 0;
var bmiMessage = "";


app.get("/bmi",function(request,response){
    response.render("bmi",{bmiValue:bmiValue,bmiMessage:bmiMessage})
    bmiValue = 0;
    bmiMessage = "";
})

app.get("/tools",function(request,response){
    response.render("tools");
})

app.get("/consultation",function(request,response){
    response.render("consult");
})
app.post("/searchMed",function(request,response){
    var medName = request.body.medicineName;
    const options = {
        method: 'GET',
        url: 'https://drug-info-and-price-history.p.rapidapi.com/1/druginfo',
        params: {drug: medName},
        headers: {
          'X-RapidAPI-Key': '59b9c4534emshdb18e8ba7f78bf7p160ce2jsndd05aa68c8dd',
          'X-RapidAPI-Host': 'drug-info-and-price-history.p.rapidapi.com'
        }
      };

    axios.request(options).then(function (res) {
        console.log(res.data)
        response.render("search",{medData:res.data[0].labeler_name || "",brandName:res.data[0].brand_name || "",dosageForm:res.data[0].dosage_form || "",route:res.data[0].route[0] || ""});
    }).catch(function (error) {
        console.error(error);
        response.render("nomed");
    });
})
app.get("/about",function(request,response){
    response.render("about")
})
app.post("/bmi",function(request,response){
    let h = request.body.height;
    let w = request.body.weight;
    bmiValue = (w/(h*h))*703;
    if(bmiValue<18.5){
        bmiMessage = "You are underweight, please take some healthy diet."
    }
    else if(bmiValue>=18.5 && bmiValue<=24.9){
        bmiMessage = "You are Normal, keep following your regular diet and healthy lifestyle to maintain your health."
    }
    else if(bmiValue>=25 && bmiValue<=29.9){
        bmiMessage = "You are Overwight, please eat some healthy food and avoid over eating. "
    }
    else{
        bmiMessage = "Obese, this can be dangerous for your health, please stop eating junkfood."
    }
    response.redirect("/bmi");
})
app.post("/",function(request,response){
    symptomArray.fill(0);
    var symptomArrayLength = Object.keys(request.body).length;
    for (let [key, value] of Object.entries(request.body)) {
        if(value === "itching") 
            symptomArray[0] = 1;
        else if(value === "skinrash")
            symptomArray[1] = 1;
        else if(value === "nodal-skin-eruptions")
            symptomArray[2] = 1;
        else if(value === "shivering")
            symptomArray[3] = 1;
        else if(value === "chills")
            symptomArray[4] = 1;
        else if(value === "joint_pain")
            symptomArray[5] = 1;
        else if(value === "stomach_pain")
            symptomArray[6] = 1;
        else if(value === "acidity")
            symptomArray[7] = 1;
        else if(value === "ulcers_on_tongue")
            symptomArray[8] = 1;
        else if(value === "muscle_wasting")
            symptomArray[9] = 1;
        else if(value === "vomiting")
            symptomArray[10] = 1;
        else if(value === "burning_micturition")
            symptomArray[11] = 1;
        else if(value === "spotting_ urination")
            symptomArray[12] = 1;
        else if(value === "fatigue")
            symptomArray[13] = 1;
        else if(value === "weight_gain")
            symptomArray[14] = 1;
        else if(value === "anxiety")
            symptomArray[15] = 1;
        else if(value === "cold_hands_and_feets")
            symptomArray[16] = 1;
        else if(value === "mood_swings")
            symptomArray[17] = 1;
        else if(value === "weight_loss")
            symptomArray[18] = 1;
        else if(value === "restlessness")
            symptomArray[19] = 1;
        else if(value === "lethargy")
            symptomArray[20] = 1;
        else if(value === "patches_in_throat")
            symptomArray[21] = 1;
        else if(value === "irregular_sugar_level")
            symptomArray[22] = 1;
        else if(value === "cough")
            symptomArray[23] = 1;
        else if(value === "high_fever")
            symptomArray[24] = 1;
        else if(value === "sunken_eyes")
            symptomArray[25] = 1;
        else if(value === "breathlessness")
            symptomArray[26] = 1;
        else if(value === "sweating")
            symptomArray[27] = 1;
        else if(value === "dehydration")
            symptomArray[28] = 1;
        else if(value === "indigestion")
            symptomArray[29] = 1;
        else if(value === "headache")
            symptomArray[30] = 1;
        else if(value === "yellowish_skin")
            symptomArray[31] = 1;
        else if(value === "dark_urine")
            symptomArray[32] = 1;
        else if(value === "nausea")
            symptomArray[33] = 1;
        else if(value === "loss_of_appetite")
            symptomArray[34] = 1;
        else if(value === "pain_behind_the_eyes")
            symptomArray[35] = 1;
        else if(value === "back_pain")
            symptomArray[36] = 1;
        else if(value === "constipation")
            symptomArray[37] = 1;
        else if(value === "abdominal_pain")
            symptomArray[38] = 1;
        else if(value === "diarrhoea")
            symptomArray[39] = 1;
        else if(value === "mild_fever")
            symptomArray[40] = 1;
        else if(value === "yellow_urine")
            symptomArray[41] = 1;
        else if(value === "yellowing_of_eyes")
            symptomArray[42] = 1;
        else if(value === "acute_liver_failure")
            symptomArray[43] = 1;
        else if(value === "fluid_overload")
            symptomArray[44] = 1;
        else if(value === "swelling_of_stomach")
            symptomArray[45] = 1;
        else if(value === "swelled_lymph_nodes")
            symptomArray[46] = 1;
        else if(value === "malaise")
            symptomArray[47] = 1;
        else if(value === "blurred_and_distorted_vision")
            symptomArray[48] = 1;
        else if(value === "phlegm")
            symptomArray[49] = 1;
        else if(value === "throat_irritation")
            symptomArray[50] = 1;
        else if(value === "redness_of_eyes")
            symptomArray[51] = 1;
        else if(value === "sinus_pressure")
            symptomArray[52] = 1;
        else if(value === "runny_nose")
            symptomArray[54] = 1;
        else if(value === "congestion")
            symptomArray[55] = 1;
        else if(value === "chest_pain")
            symptomArray[56] = 1;
        else if(value === "weakness_in_limbs")
            symptomArray[57] = 1;
        else if(value === "fast_heart_rate")
            symptomArray[58] = 1;
        else if(value === "pain_during_bowel_movements")
            symptomArray[59] = 1;
        else if(value === "pain_in_anal_region")
            symptomArray[60] = 1;
        else if(value === "bloody_stool")
            symptomArray[61] = 1;
        else if(value === "irritation_in_anus")
            symptomArray[62] = 1;
        else if(value === "neck_pain")
            symptomArray[63] = 1;
        else if(value === "dizziness")
            symptomArray[64] = 1;
        else if(value === "cramps")
            symptomArray[65] = 1;
        else if(value === "bruising")
            symptomArray[66] = 1;
        else if(value === "obesity")
            symptomArray[67] = 1;
        else if(value === "swollen_legs")
            symptomArray[68] = 1;
        else if(value === "swollen_blood_vessels")
            symptomArray[69] = 1;
        else if(value === "puffy_face_and_eyes")
            symptomArray[70] = 1;
        else if(value === "enlarged_thyroid")
            symptomArray[71] = 1;
        else if(value === "brittle_nails")
            symptomArray[72] = 1;
        else if(value === "swollen_extremeties")
            symptomArray[73] = 1;
        else if(value === "excessive_hunger")
            symptomArray[74] = 1;
        else if(value === "extra_marital_contacts")
            symptomArray[75] = 1;
        else if(value === "drying_and_tingling_lips")
            symptomArray[76] = 1;
        else if(value === "slurred_speech")
            symptomArray[77] = 1;
        else if(value === "knee_pain")
            symptomArray[78] = 1;
        else if(value === "hip_joint_pain")
            symptomArray[79] = 1;
        else if(value === "muscle_weakness")
            symptomArray[80] = 1;
        else if(value === "stiff_neck")
            symptomArray[81] = 1;
        else if(value === "swelling_joints")
            symptomArray[82] = 1;
        else if(value === "movement_stiffness")
            symptomArray[83] = 1;
        else if(value === "spinning_movements")
            symptomArray[84] = 1;
        else if(value === "loss_of_balance")
            symptomArray[85] = 1;
        else if(value === "unsteadiness")
            symptomArray[86] = 1;
        else if(value === "weakness_of_one_body_side")
            symptomArray[87] = 1;
        else if(value === "loss_of_smell")
            symptomArray[88] = 1;
        else if(value === "bladder_discomfort")
            symptomArray[89] = 1;
        else if(value === "foul_smell_of urine")
            symptomArray[90] = 1;
        else if(value === "continuous_feel_of_urine")
            symptomArray[91] = 1;
        else if(value === "passage_of_gases")
            symptomArray[92] = 1;
        else if(value === "internal_itching")
            symptomArray[93] = 1;
        else if(value === "toxic_look_(typhos)")
            symptomArray[94] = 1;
        else if(value === "depression")
            symptomArray[95] = 1;
        else if(value === "irritability")
            symptomArray[96] = 1;
        else if(value === "muscle_pain")
            symptomArray[97] = 1;
        else if(value === "altered_sensorium")
            symptomArray[98] = 1;
        else if(value === "red_spots_over_body")
            symptomArray[99] = 1;
        else if(value === "belly_pain")
            symptomArray[100] = 1;
        else if(value === "abnormal_menstruation")
            symptomArray[101] = 1;
        else if(value === "dischromic _patches")
            symptomArray[102] = 1;
        else if(value === "watering_from_eyes")
            symptomArray[103] = 1;
        else if(value === "increased_appetite")
            symptomArray[104] = 1;
        else if(value === "polyuria")
            symptomArray[105] = 1;
        else if(value === "family_history")
            symptomArray[106] = 1;
        else if(value === "mucoid_sputum")
            symptomArray[107] = 1;
        else if(value === "rusty_sputum")
            symptomArray[108] = 1;
        else if(value === "lack_of_concentration")
            symptomArray[109] = 1;
        else if(value === "visual_disturbances")
            symptomArray[110] = 1;
        else if(value === "receiving_blood_transfusion")
            symptomArray[111] = 1;
        else if(value === "receiving_unsterile_injections")
            symptomArray[112] = 1;
        else if(value === "coma")
            symptomArray[113] = 1;
        else if(value === "stomach_bleeding")
            symptomArray[114] = 1;
        else if(value === "distention_of_abdomen")
            symptomArray[115] = 1;
        else if(value === "history_of_alcohol_consumption")
            symptomArray[116] = 1;
        else if(value === "fluid_overload")
            symptomArray[117] = 1;
        else if(value === "blood_in_sputum")
            symptomArray[118] = 1;
        else if(value === "prominent_veins_on_calf")
            symptomArray[119] = 1;
        else if(value === "palpitations")
            symptomArray[120] = 1;
        else if(value === "painful_walking")
            symptomArray[121] = 1;
        else if(value === "pus_filled_pimples")
            symptomArray[122] = 1;
        else if(value === "blackheads")
            symptomArray[123] = 1;
        else if(value === "scurring")
            symptomArray[124] = 1;
        else if(value === "skin_peeling")
            symptomArray[125] = 1;
        else if(value === "silver_like_dusting")
            symptomArray[126] = 1;
        else if(value === "small_dents_in_nails")
            symptomArray[127] = 1;
        else if(value === "inflammatory_nails")
            symptomArray[128] = 1;
        else if(value === "blister")
            symptomArray[129] = 1;
        else if(value === "red_sore_around_nose")
            symptomArray[130] = 1;
        else if(value === "yellow_crust_ooze")
            symptomArray[131] = 1;
    }
    const pythonProcess = spawn('python', ['myModel.py', JSON.stringify(symptomArray)]);
    pythonProcess.stdout.on('data', (data) => {
        
        const outputData = JSON.parse(data.toString());
        disease = outputData[0];
        response.redirect("/");
      });
})

app.listen(3000,console.log("server started at 3000"));
// array size - 132